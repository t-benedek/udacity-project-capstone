Github Repository can be found here: 
https://github.com/t-benedek/udacity-project-capstone

Comments:
I wanted to experiment with the quarkus framework what you can see on the naming of ressources. 
Nethertheless I had so much pain with AWS EKS that I did not manage to find enough time though. 